package com.nobigcorps.strawberrymc.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class RadoniteSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 254, 6f, 0, 14, TagKey.create(Registries.ITEM, Identifier.parse("strawberrymc:radonite_sword_repair_items")));

	public RadoniteSwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 5f, -2f));
	}
}